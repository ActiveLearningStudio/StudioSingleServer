/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'pt-br', {
	clear: 'Limpar',
	highlight: 'Grifar',
	options: 'Opções de Cor',
	selected: 'Cor Selecionada',
	title: 'Selecione uma Cor'
} );
