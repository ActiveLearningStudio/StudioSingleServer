/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'sq', {
	alt: 'Tekst Alternativ',
	btnUpload: 'Dërgo në server',
	captioned: 'Foto e titulluar',
	captionPlaceholder: 'Titulli',
	infoTab: 'Informacione mbi Fotografinë',
	lockRatio: 'Mbyll Racionin',
	menu: 'Karakteristikat e Fotografisë',
	pathName: 'foto',
	pathNameCaption: 'titull',
	resetSize: 'Rikthe Madhësinë',
	resizer: 'Kliko dhe tërhiqe për ndryshim të madhësisë',
	title: 'Karakteristikat e Fotografisë',
	uploadTab: 'Ngarko',
	urlMissing: 'Mungon URL e burimit të fotografisë.',
	altMissing: 'Teksti alternativ mungon.'
} );
