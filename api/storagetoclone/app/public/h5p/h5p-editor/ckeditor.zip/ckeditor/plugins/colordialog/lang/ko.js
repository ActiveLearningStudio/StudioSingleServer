/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'ko', {
	clear: '비우기',
	highlight: '강조',
	options: '색상 옵션',
	selected: '선택된 색상',
	title: '색상 선택'
} );
